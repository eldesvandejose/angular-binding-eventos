import { Component } from '@angular/core';

@Component({
  selector: 'a01-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  urls = [
    'https://eldesvandejose.com',
    'http://httpmasters.es'
  ];

  /**
   * Los estados iniciales de los botones
   */
  boton_verde_desactivado = false;
  boton_rojo_desactivado = true;
  boton_azul_desactivado = true;

  /**
   * Los textos iniciales de los botones
   */
  texto_activar = 'Activar botón de saludo';
  texto_desactivar = 'Este botón no funciona ahora';
  texto_saludar = 'Este botón no funciona ahora';

  /**
   * Las funciones que responden al binding de eventos
   */
  activarSaludo() {
    this.boton_verde_desactivado = true;
    this.boton_rojo_desactivado = false;
    this.boton_azul_desactivado = false;
    this.texto_activar = 'Este botón no funciona ahora';
    this.texto_desactivar = 'Desactivar botón de saludo';
    this.texto_saludar = 'Mostrar saludo en un alert';
  }
  desactivarSaludo() {
    this.boton_verde_desactivado = false;
    this.boton_rojo_desactivado = true;
    this.boton_azul_desactivado = true;
    this.texto_activar = 'Activar botón de saludo';
    this.texto_desactivar = 'Este botón no funciona ahora';
    this.texto_saludar = 'Este botón no funciona ahora';
  }
  saludar() {
    alert('Has pulsado el botón');
  }
}
